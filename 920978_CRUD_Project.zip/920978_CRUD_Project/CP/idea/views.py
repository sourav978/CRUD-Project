from django.shortcuts import render,redirect

from airtel.models import Customer
from .forms import Customerform

# Create your views here.

def index(request):
    return render(request,'index.html')

def upload1(request):
   # form=Customerform() 
    if(request.method=='POST'):
        z=Customerform(request.POST)
        if z.is_valid():
            z.save()
            return redirect('/show')
    else:
        z=Customerform()
        return render(request,'index.html',{'hi':z})  #Error

def show(request):
    a=Customer.objects.all()
    return render(request,'upload.html',{'hello':a})

def update(request,id):
    b=Customer.objects.get(id=id)
    if request.method=='POST':
        form=Customerform(request.POST,instance=b)
        if form.is_valid():
            form.save()
            return redirect("/upload")
    else:
        form=Customerform(instance=b)
        return render(request,"index.html",{'hi':form})

def delete(request,id):
    x=Customer.objects.get(id=id)
    x.delete()
    return redirect("/")



 